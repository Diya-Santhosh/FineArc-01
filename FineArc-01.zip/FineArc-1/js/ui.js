var images = ["second-slide.jpg", "second-slide-color.jpg"];
      $(function () {
        var i = 0;
        $("#dvImage1").css("background-image", "url(images/" + images[i] + ")");
        setInterval(function () {
          i++;
          if (i == images.length) {
            i = 0;
          }
          $("#dvImage1").fadeOut("slow", function () {
            $(this).css("background-image", "url(images/" + images[i] + ")");
            $(this).fadeIn("slow");
          });
        }, 5000);
      });